/*************************************************************************
#	 FileName	: server.c
#	 Author		: fengjunhui 
#	 Email		: 18883765905@163.com 
#	 Created	: 2018年12月29日 星期六 13时44分59秒
 ************************************************************************/

#include<stdio.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/select.h>
#include <pthread.h>
#include <sqlite3.h>

#include "common.h"


sqlite3 *db;  //仅服务器使用

void add_history(MSG* msg, char * s)
{
	char no[10]={0};
//	char text[DATALEN] = {0};
	char who[NAMELEN] ={0};
	char whos[NAMELEN] ={0};
	char times[DATALEN] = {0};
	char sql[DATALEN] = {0};
	time_t ftime;
	struct tm * pm = NULL;
    char * errmsg = NULL;
	time(&ftime);
	pm = localtime(&ftime);

	sprintf(times,"%04d-%02d-%02d %02d:%02d:%02d",pm->tm_year+1900,pm->tm_mon,pm->tm_mday,pm->tm_hour,pm->tm_min,pm->tm_sec);
	sprintf(who,"---%s---",(msg->usertype == 0?"admin":"user"));
	
//	sprintf(whos,"%s ",(msg->usertype == 0?"admin":"user"));
//	strncat(text,who,strlen(who));
//	strcat(text,"(");



//	itoa(staffno,no);
//	strcat(text,no);
//	strcat(text,")");
//	printf("----------:%s\n",s);
	
	//strncat(text, s, strlen(s));
//	strcat(text, s);
//	printf("****:%s\n",text);
	

	sprintf(sql,"insert into historyinfo values('%s','%s','%s');",times,who,s);

	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != 0) { //执行sql语句
		printf("%s\n", errmsg);
	}
	else {
		printf("sqlite3_exec success!\n");
	}
}








int process_user_or_admin_login_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);
	//封装sql命令，表中查询用户名和密码－存在－登录成功－发送响应－失败－发送失败响应	
	char sql[DATALEN] = {0};
	char *errmsg;
	char **result;
	int nrow,ncolumn;
	char s[DATALEN] = {0};

	msg->info.usertype =  msg->usertype;
	strcpy(msg->info.name,msg->username);
	strcpy(msg->info.passwd,msg->passwd);
	
	printf("usrtype: %#x-----usrname: %s---passwd: %s.\n",msg->info.usertype,msg->info.name,msg->info.passwd);
	sprintf(sql,"select * from usrinfo where usertype=%d and name='%s' and passwd='%s';",msg->info.usertype,msg->info.name,msg->info.passwd);
	if(sqlite3_get_table(db,sql,&result,&nrow,&ncolumn,&errmsg) != SQLITE_OK){
		printf("---****----%s.\n",errmsg);		
	}
	else {
		//printf("----nrow-----%d,ncolumn-----%d.\n",nrow,ncolumn);		
		if(nrow == 0){
			strcpy(msg->recvmsg,"name or passwd failed.\n");
			send(acceptfd,msg,sizeof(MSG),0);
		 }
		else {
			strcpy(msg->recvmsg, "OK");
			send(acceptfd, msg, sizeof(MSG), 0);
		}
	}
	return 0;	
}

/* 处理用户修改请求 */
int process_user_modify_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);

	char sql[DATALEN] = {0};
	char *errmsg;
	char **result;
	int nrow,ncolumn;
	char s[DATALEN] = {0};

	switch(msg->flags)
	{
		case 1:
			sprintf(sql, "update usrinfo set addr='%s' where staffno=%d;", msg->info.addr, msg->info.no);
			sprintf(s,"用户%s修改工号为%d的家庭地址为%s。", msg->info.name, msg->info.no, msg->info.addr);
			add_history(msg, s);
			printf("-----%s\n",s);
			break;
		case 2:
			sprintf(sql, "update usrinfo set phone='%s' where staffno=%d;", msg->info.phone, msg->info.no);
			sprintf(s,"用户%s修改工号为%d的电话为%s。", msg->info.name, msg->info.no, msg->info.phone);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		case 3:
			sprintf(sql, "update usrinfo set passwd='%s' where staffno=%d;", msg->info.passwd, msg->info.no);
			sprintf(s,"用户%s修改工号为%d的密码为%s。", msg->info.name, msg->info.no, msg->info.passwd);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		default:
			break;
	}


	if(sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK) {
		fprintf(stderr, "get table: %s\n", errmsg);
		return -1;
	}
	else{	
		strcpy(msg->recvmsg, "OK");
		send(acceptfd,msg,sizeof(MSG),0);
	}
}


/* 处理用户查询请求 */
int process_user_query_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);

	char sql[DATALEN] = {0};
	char *errmsg = NULL;
	char **result = NULL;
	int nrow, ncolumn;
	char s[DATALEN] = {0};

	sprintf(sql, "select * from usrinfo where name='%s';", msg->info.name);
	sprintf(s,"用户%s查询信息。", msg->info.name);
	add_history(msg, s);
	printf("-----%s\n",s);


	if(sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK) {
		fprintf(stderr, "get table: %s\n", errmsg);
		return -1;
	}
	else {
		int i, j, count = 0;
		memset(msg->recvmsg, 0, sizeof(msg->recvmsg));

		for (i = 1; i <= nrow; i++)
		{
			memset(msg->recvmsg, 0, sizeof(recvmsg));
			for (j = 0; j < ncolumn; j++)
			{
				if(result[i*ncolumn+j] == NULL)  //字段值为空，则result[count]变成空指针
				{
					result[i*ncolumn+j] = " ";   //若引用空指针的值，会造成段错误，所以将空元素指向空格字符
				}

				strcat(msg->recvmsg, result[i*ncolumn+j]);
				strcat(msg->recvmsg, "    ");
			}
			strcat(msg->recvmsg, "\n");			
		}
		send(acceptfd, msg, sizeof(MSG), 0);
	}

	return 0;
}


int process_admin_modify_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);

	char sql[DATALEN] = {0};
	char *errmsg;
	char **result;
	int nrow,ncolumn;
	char s[DATALEN] = {0};

	switch(msg->flags)
	{
		case 1:
			sprintf(sql, "update usrinfo set name='%s' where staffno=%d;", msg->info.name, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的名字为%s。", msg->info.no, msg->info.name);
			add_history(msg, s);
			printf("-----%s\n",s);
			break;
		case 2:
			sprintf(sql, "update usrinfo set age=%d where staffno=%d;", msg->info.age, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的年龄为%d。", msg->info.no, msg->info.age);
			add_history(msg, s);
			printf("-----%s\n",s);			
			break;
		case 3:
			sprintf(sql, "update usrinfo set addr='%s' where staffno=%d;", msg->info.addr, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的家庭地址为%s。", msg->info.no, msg->info.addr);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		case 4:
			sprintf(sql, "update usrinfo set phone='%s' where staffno=%d;", msg->info.phone, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的电话为'%s'。", msg->info.no, msg->info.phone);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		case 5:	
			sprintf(sql, "update usrinfo set work='%s' where staffno=%d;", msg->info.work, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的职位为%s。", msg->info.no, msg->info.work);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		case 6:
			sprintf(sql, "update usrinfo set salary=%lf where staffno=%d;", msg->info.salary, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的工资为%lf。", msg->info.no, msg->info.salary);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		case 7:
			sprintf(sql, "update usrinfo set date='%s' where staffno=%d;", msg->info.date, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的入职年月为%s。", msg->info.no, msg->info.date);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		case 8:
			sprintf(sql, "update usrinfo set level=%d where staffno=%d;", msg->info.level, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的评级为%d。", msg->info.no, msg->info.level);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		case 9:
			sprintf(sql, "update usrinfo set passwd='%s' where staffno=%d;", msg->info.passwd, msg->info.no);
			sprintf(s,"管理员admin修改工号为%d的密码为%s。", msg->info.no, msg->info.passwd);
			add_history(msg, s);
			printf("-----%s\n",s);	
			break;
		default:
			break;
	}


	if(sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK) {
		fprintf(stderr, "get table: %s\n", errmsg);
		return -1;
	}
	else{	
		strcpy(msg->recvmsg, "OK");
		send(acceptfd,msg,sizeof(MSG),0);
	}

}


int process_admin_adduser_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);

	char sql[DATALEN] = {0};
	char *errmsg;
	char **result;
	int nrow,ncolumn;
	char s[DATALEN] = {0};
	
	sprintf(sql, "insert into usrinfo values(%d, %d, '%s', '%s', %d, '%s', '%s', '%s', '%s', %d, %lf);", \
		msg->info.no, msg->info.usertype, msg->info.name, msg->info.passwd, msg->info.age, msg->info.phone, msg->info.addr, msg->info.work, msg->info.date, msg->info.level, msg->info.salary);

	if(sqlite3_get_table(db,sql,&result,&nrow,&ncolumn,&errmsg) != SQLITE_OK){
		printf("---****----%s.\n",errmsg);	
		return -1;	
	}
	else{
		strcpy(msg->recvmsg, "OK");
		send(acceptfd, msg, sizeof(MSG), 0);
		sprintf(s,"管理员admin添加了%s用户。", msg->info.name);
		add_history(msg, s);
		printf("-----%s\n",s);
	}

	return 0;
}


int process_admin_deluser_request(int acceptfd, MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);

	char sql[DATALEN] = {0};
	char *errmsg;
	char **result;
	int nrow,ncolumn;
	char s[DATALEN] = {0};
	
	sprintf(sql,"delete from usrinfo where staffno=%d and name='%s';", msg->info.no, msg->info.name);
	
	if(sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK){
		printf("---****----%s.\n",errmsg);	
		return(-1);	
	}else{	
		strcpy(msg->recvmsg, "OK");
		send(acceptfd, msg, sizeof(MSG), 0);
		sprintf(s,"管理员admin删除了%s用户。", msg->info.name);
		add_history(msg, s);
		printf("-----%s\n",s);				
	}
	return 0;
}


int process_admin_query_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);

	char sql[DATALEN] = {0};
	char *errmsg = NULL;
	char **result = NULL;
	int nrow, ncolumn;
	char s[DATALEN] = {0};

	if(msg->flags == 1) {		
		sprintf(sql, "select * from usrinfo;");
		sprintf(s,"管理员admin查询所有用户信息。");
		add_history(msg, s);
		printf("-----%s\n",s);	
	}	
	else {
		sprintf(sql, "select * from usrinfo where name='%s';", msg->info.name);
		sprintf(s,"管理员admin查询用户%s的信息。", msg->info.name);
		add_history(msg, s);
		printf("-----%s\n",s);
	}

	if(sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK) {
		fprintf(stderr, "get table: %s\n", errmsg);
		return -1;
	}
	else {
		int i, j;
		memset(msg->recvmsg, 0, sizeof(msg->recvmsg));	

		for (i = 1; i <= nrow; i++)
		{
			for (j = 0; j < ncolumn; j++)
			{
				if(result[i*ncolumn+j] == NULL)  //字段值为空，则result[count]变成空指针
				{
					result[i*ncolumn+j] = " ";   //若引用空指针的值，会造成段错误，所以将空元素指向空格字符
				}

				strcat(msg->recvmsg, result[i*ncolumn+j]);
				strcat(msg->recvmsg, "    ");
			}
			strcat(msg->recvmsg, "\n");
		}	
		send(acceptfd, msg, sizeof(MSG), 0);
	}
}


int process_admin_history_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);

	char sql[DATALEN] = {0};
	char * errmsg = NULL;
	char ** result = NULL;
	int nrow = 0, ncolumn = 0;
	int i = 0, j = 0;

	sprintf(sql, "select * from historyinfo;");

	if(sqlite3_get_table(db, sql, &result, &nrow, &ncolumn, &errmsg) != SQLITE_OK) {
		printf("---****----%s.\n",errmsg);	
		return -1;
	}
	else {
		msg->flags = nrow;

		if(nrow == 0) {
			strcpy(msg->recvmsg, "no historyinfo!");
			send(acceptfd, msg, sizeof(MSG), 0);
		}
		else {
			for(i=1; i<=nrow; i++)  //第0行是表头
			{
				memset(msg->recvmsg, 0, DATALEN);

				for(j=0; j<ncolumn; j++)
				{
					strcat(msg->recvmsg, result[i*ncolumn+j]);
				}
				send(acceptfd, msg, sizeof(MSG), 0);
			}
		}
	}
	return 0;
}


int process_client_quit_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);
	close(acceptfd);
	exit(0);
	return 0;
}

/* 处理客户端请求 */
int process_client_request(int acceptfd,MSG *msg)
{
	printf("------------%s-----------%d.\n",__func__,__LINE__);
	switch (msg->msgtype)
	{
		case USER_LOGIN:
		case ADMIN_LOGIN:
			process_user_or_admin_login_request(acceptfd,msg); //用户或管理员注册请求
			break;
		case USER_MODIFY:
			process_user_modify_request(acceptfd,msg);  //处理用户修改请求
			break;
		case USER_QUERY:
			process_user_query_request(acceptfd,msg);   //处理用户查询请求
			break;
		case ADMIN_MODIFY:
			process_admin_modify_request(acceptfd,msg);  //管理员修改请求
			break;

		case ADMIN_ADDUSER:
			process_admin_adduser_request(acceptfd,msg);
			break;

		case ADMIN_DELUSER:
			process_admin_deluser_request(acceptfd,msg);
			break;
		case ADMIN_QUERY:
			process_admin_query_request(acceptfd,msg);  //管理员查询
			break;
		case ADMIN_HISTORY:
			process_admin_history_request(acceptfd,msg); //管理员查询历史记录
			break;
		case QUIT:
			process_client_quit_request(acceptfd,msg);  //客户端退出
			break;
		default:
			break;
	}

}


int main(int argc, const char *argv[])
{
	//socket->填充->绑定->监听->等待连接->数据交互->关闭 
	int sockfd;
	int acceptfd;
	ssize_t recvbytes;
	struct sockaddr_in serveraddr;
	struct sockaddr_in clientaddr;
	socklen_t addrlen = sizeof(serveraddr);
	socklen_t cli_len = sizeof(clientaddr);

	MSG msg;
	//thread_data_t tid_data;
	char *errmsg;

	if(sqlite3_open(STAFF_DATABASE,&db) != SQLITE_OK){
		printf("%s.\n",sqlite3_errmsg(db));
	}else{
		printf("the database open success.\n");
	}

	if(sqlite3_exec(db,"create table usrinfo(staffno integer,usertype integer,name text,passwd text,age integer,phone text,addr text,work text,date text,level integer,salary REAL);",NULL,NULL,&errmsg)!= SQLITE_OK){
		printf("%s.\n",errmsg);
	}else{
		printf("create usrinfo table success.\n");
	}

	if(sqlite3_exec(db,"create table historyinfo(time text,name text,words text);",NULL,NULL,&errmsg)!= SQLITE_OK){
		printf("%s.\n",errmsg);
	}else{ //华清远见创客学院         嵌入式物联网方向讲师
		printf("create historyinfo table success.\n");
	}

	//创建网络通信的套接字
	sockfd = socket(AF_INET,SOCK_STREAM, 0);
	if(sockfd == -1){
		perror("socket failed.\n");
		exit(-1);
	}
	printf("sockfd :%d.\n",sockfd); 

	
	/*优化4： 允许绑定地址快速重用 */
	int b_reuse = 1;
	setsockopt (sockfd, SOL_SOCKET, SO_REUSEADDR, &b_reuse, sizeof (int));
	
	//填充网络结构体
	memset(&serveraddr,0,sizeof(serveraddr));
	memset(&clientaddr,0,sizeof(clientaddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port   = htons(atoi(argv[2]));
	serveraddr.sin_addr.s_addr = inet_addr(argv[1]);
//	serveraddr.sin_port   = htons(8001);
//	serveraddr.sin_addr.s_addr = inet_addr("192.168.1.169");


	//绑定网络套接字和网络结构体
	if(bind(sockfd, (const struct sockaddr *)&serveraddr,addrlen) == -1){
		printf("bind failed.\n");
		exit(-1);
	}

	//监听套接字，将主动套接字转化为被动套接字
	if(listen(sockfd,10) == -1){
		printf("listen failed.\n");
		exit(-1);
	}

	//定义一张表
	fd_set readfds,tempfds;
	//清空表
	FD_ZERO(&readfds);
	FD_ZERO(&tempfds);
	//添加要监听的事件
	FD_SET(sockfd,&readfds);
	int nfds = sockfd;
	int retval;
	int i = 0;

#if 0 //添加线程控制部分
	pthread_t thread[N];
	int tid = 0;
#endif

	while(1){
		tempfds = readfds;
		//记得重新添加
		retval =select(nfds + 1, &tempfds, NULL,NULL,NULL);
		//判断是否是集合里关注的事件
		for(i = 0;i < nfds + 1; i ++){
			if(FD_ISSET(i,&tempfds)){
				if(i == sockfd){
					//数据交互 
					acceptfd = accept(sockfd,(struct sockaddr *)&clientaddr,&cli_len);
					if(acceptfd == -1){
						printf("acceptfd failed.\n");
						exit(-1);
					}
					printf("ip : %s.\n",inet_ntoa(clientaddr.sin_addr));
					FD_SET(acceptfd,&readfds);
					nfds = nfds > acceptfd ? nfds : acceptfd;
				}else{
					recvbytes = recv(i,&msg,sizeof(msg),0);
					printf("msg.type :%#x.\n",msg.msgtype);
					if(recvbytes == -1){
						printf("recv failed.\n");
						continue;
					}else if(recvbytes == 0){
						printf("peer shutdown.\n");
						close(i);
						FD_CLR(i, &readfds);  //删除集合中的i
					}else{
						process_client_request(i,&msg);
					}
				}
			}
		}
	}
	close(sockfd);

	return 0;
}







#if 0
					//tid_data.acceptfd = acceptfd;   //暂时不使用这种方式
					//tid_data.state	  = 1;
					//tid_data.thread   = thread[tid++];	
					//pthread_create(&tid_data.thread, NULL,client_request_handler,(void *)&tid_data);
#endif 

#if 0
void *client_request_handler(void * args)
{
	thread_data_t *tiddata= (thread_data_t *)args;

	MSG msg;
	int recvbytes;
	printf("tiddata->acceptfd :%d.\n",tiddata->acceptfd);

	while(1){  //可以写到线程里--晚上的作业---- UDP聊天室
		//recv 
		memset(msg,sizeof(msg),0);
		recvbytes = recv(tiddata->acceptfd,&msg,sizeof(msg),0);
		if(recvbytes == -1){
			printf("recv failed.\n");
			close(tiddata->acceptfd);
			pthread_exit(0);
		}else if(recvbytes == 0){
			printf("peer shutdown.\n");
			pthread_exit(0);
		}else{
			printf("msg.recvmsg :%s.\n",msg.recvmsg);
			strcat(buf,"*-*");
			send(tiddata->acceptfd,&msg,sizeof(msg),0);
		}
	}

}

#endif 


